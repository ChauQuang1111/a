import "./app.css";

function App() {
  return (
    <>
      <h1 className="text-[20px] text-blue-600">Hello react + vite app</h1>
    </>
  );
}

export default App;
